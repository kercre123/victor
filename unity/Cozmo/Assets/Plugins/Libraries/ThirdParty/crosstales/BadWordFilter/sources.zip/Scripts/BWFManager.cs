using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using Crosstales.BWF.Filter;
using Crosstales.BWF.Model;
using Crosstales.BWF.Manager;
using Crosstales.BWF.Util;

namespace Crosstales.BWF
{
    /// <summary>BWF is a multi-manager for all available managers.</summary>
    [ExecuteInEditMode]
    public class BWFManager : MonoBehaviour
    {

        private GameObject root;

        #region Static properties

        /// <summary>Checks the readiness status of all managers.</summary>
        /// <returns>True if all managers are ready.</returns>
        public static bool isReady
        {
            get
            {
                return BadWordManager.isReady && DomainManager.isReady && CapitalizationManager.isReady && PunctuationManager.isReady;
            }
        }

        #endregion

        #region MonoBehaviour methods

        public void OnEnable()
        {
            root = transform.root.gameObject;
        }

        public void Update()
        {
            if (Helper.isEditorMode)
            {
                if (root != null)
                {
                    root.name = Constants.MANAGER_SCENE_OBJECT_NAME; //ensure name
                }
            }
        }

        #endregion

        #region Static methods

        /// <summary>Loads the filter of a manager.</summary>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        public static void Load(ManagerMask mask = ManagerMask.All)
        {
            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                BadWordManager.Load();
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                DomainManager.Load();
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All)
            {
                CapitalizationManager.Load();
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All)
            {
                PunctuationManager.Load();
            }
        }

        /// <summary>Returns the filter of a manager.</summary>
        /// <param name="mask">Active manager (default: ManagerMask.BadWord, optional)</param>
        /// <returns>Filter for the selected manager</returns>
        public static BaseFilter Filter(ManagerMask mask = ManagerMask.BadWord)
        {
            BaseFilter result = BadWordManager.Filter;

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain)
            {
                result = DomainManager.Filter;
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization)
            {
                result = CapitalizationManager.Filter;
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation)
            {
                result = PunctuationManager.Filter;
            }

            return result;
        }

        /// <summary>Returns all sources for a manager.</summary>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <returns>List with all sources for the selected manager</returns>
        public static List<Source> Sources(ManagerMask mask = ManagerMask.All)
        {
            List<Source> result = new List<Source>(30);

            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result.AddRange(BadWordManager.Sources);
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result.AddRange(DomainManager.Sources);
            }

            //         if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All) {
            //            result.AddRange(CapitalizationManager.Sources);
            //         }

            //         if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All) {
            //            result.AddRange(PunctuationManager.Sources);
            //         }

            return result.Distinct().OrderBy(x => x.Name).ToList();
        }

        /// <summary>Searches for unwanted words in a text.</summary>
        /// <param name="testString">Text to check</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="sources">Relevant sources (e.g. "english")</param>
        /// <returns>True if a match was found</returns>
        public static bool Contains(string testString, ManagerMask mask = ManagerMask.All, params string[] sources)
        {
            return (((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All) && BadWordManager.Contains(testString, sources)) ||
               (((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All) && DomainManager.Contains(testString, sources)) ||
               (((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All) && CapitalizationManager.Contains(testString)) ||
               (((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All) && PunctuationManager.Contains(testString));
        }

        /// <summary>Searches for unwanted words in a text (call as thread).</summary>
        /// <param name="result">out-parameter: true if a match was found</param>
        /// <param name="testString">Text to check</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="sources">Relevant sources (e.g. "english")</param>
        public static void ContainsMT(out bool result, string testString, ManagerMask mask = ManagerMask.All, params string[] sources)
        {
            result = (((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All) && BadWordManager.Contains(testString, sources)) ||
               (((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All) && DomainManager.Contains(testString, sources)) ||
               (((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All) && CapitalizationManager.Contains(testString)) ||
               (((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All) && PunctuationManager.Contains(testString));
        }

        /// <summary>Searches for unwanted words in a text.</summary>
        /// <param name="testString">Text to check</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="sources">Relevant sources (e.g. "english")</param>
        /// <returns>List with all the matches</returns>
        public static List<string> GetAll(string testString, ManagerMask mask = ManagerMask.All, params string[] sources)
        {
            List<string> result = new List<string>();

            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result.AddRange(BadWordManager.GetAll(testString, sources));
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result.AddRange(DomainManager.GetAll(testString, sources));
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result.AddRange(CapitalizationManager.GetAll(testString, sources));
                result.AddRange(CapitalizationManager.GetAll(testString));
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result.AddRange(PunctuationManager.GetAll(testString, sources));
                result.AddRange(PunctuationManager.GetAll(testString));
            }

            return result.Distinct().OrderBy(x => x).ToList();
        }

        /// <summary>Searches for unwanted words in a text (call as thread).</summary>
        /// <param name="result">out-parameter: List with all the matches</param>
        /// <param name="testString">Text to check</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="sources">Relevant sources (e.g. "english")</param>
        public static void GetAllMT(out List<string> result, string testString, ManagerMask mask = ManagerMask.All, params string[] sources)
        {
            List<string> tmp = new List<string>();

            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                tmp.AddRange(BadWordManager.GetAll(testString, sources));
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                tmp.AddRange(DomainManager.GetAll(testString, sources));
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result.AddRange(CapitalizationManager.GetAll(testString, sources));
                tmp.AddRange(CapitalizationManager.GetAll(testString));
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result.AddRange(PunctuationManager.GetAll(testString, sources));
                tmp.AddRange(PunctuationManager.GetAll(testString));
            }

            result = tmp.Distinct().OrderBy(x => x).ToList();
        }

        /// <summary>Searches and replaces all unwanted words in a text.</summary>
        /// <param name="testString">Text to check</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="sources">Relevant sources (e.g. "english")</param>
        /// <returns>Clean text</returns>
        public static string ReplaceAll(string testString, ManagerMask mask = ManagerMask.All, params string[] sources)
        {
            string result = testString ?? string.Empty;

            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = BadWordManager.ReplaceAll(result, sources);
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = DomainManager.ReplaceAll(result, sources);
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result = CapitalizationManager.ReplaceAll(result, sources);
                result = CapitalizationManager.ReplaceAll(result);
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result = PunctuationManager.ReplaceAll(result, sources);
                result = PunctuationManager.ReplaceAll(result);
            }

            return result;
        }

        /// <summary>Searches and replaces all unwanted words in a text (call as thread).</summary>
        /// <param name="result">out-parameter: clean text</param>
        /// <param name="testString">Text to check</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="sources">Relevant sources (e.g. "english")</param>
        public static void ReplaceAllMT(out string result, string testString, ManagerMask mask = ManagerMask.All, params string[] sources)
        {
            result = testString ?? string.Empty;

            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = BadWordManager.ReplaceAll(result, sources);
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = DomainManager.ReplaceAll(result, sources);
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result = CapitalizationManager.ReplaceAll(result, sources);
                result = CapitalizationManager.ReplaceAll(result);
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All)
            {
                //result = PunctuationManager.ReplaceAll(result, sources);
                result = PunctuationManager.ReplaceAll(result);
            }
        }

        /// <summary>
        /// Replaces all unwanted words in a text.
        /// Use this method if you already have a list of bad words (e.g. from the 'GetAll()' method).
        /// </summary>
        /// <param name="text">Text containig unwanted words</param>
        /// <param name="mask">Active manager (default: ManagerMask.All, optional)</param>
        /// <param name="unwantedWords">Unwanted words to replace</param>
        /// <returns>Clean text</returns>
        public static string Replace(string text, List<string> unwantedWords, ManagerMask mask = ManagerMask.All)
        {
            string result = text ?? string.Empty;

            if ((mask & ManagerMask.BadWord) == ManagerMask.BadWord || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = BadWordManager.Replace(result, unwantedWords);
            }

            if ((mask & ManagerMask.Domain) == ManagerMask.Domain || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = DomainManager.Replace(result, unwantedWords);
            }

            if ((mask & ManagerMask.Capitalization) == ManagerMask.Capitalization || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = CapitalizationManager.Replace(result, unwantedWords);
            }

            if ((mask & ManagerMask.Punctuation) == ManagerMask.Punctuation || (mask & ManagerMask.All) == ManagerMask.All)
            {
                result = PunctuationManager.Replace(result, unwantedWords);
            }

            return result;
        }

        /// <summary>Marks the text with a prefix and postfix from a list of words.</summary>
        /// <param name="text">Text containig unwanted words</param>
        /// <param name="unwantedWords">Unwanted words to mark</param>
        /// <param name="prefix">Prefix for every found unwanted word (optional)</param>
        /// <param name="postfix">Postfix for every found unwanted word (optional)</param>
        /// <returns>Text with marked unwanted words</returns>
        public static string Mark(string text, List<string> unwantedWords, string prefix = "<b><color=red>", string postfix = "</color></b>")
        {
            string result = text ?? string.Empty;

            //The different mangers all do the same.
            result = BadWordManager.Mark(result, unwantedWords, prefix, postfix);

            return result;
        }

        /// <summary>Unmarks the text with a prefix and postfix.</summary>
        /// <param name="text">Text with marked unwanted words</param>
        /// <param name="prefix">Prefix for every found unwanted word (optional)</param>
        /// <param name="postfix">Postfix for every found unwanted word (optional)</param>
        /// <returns>Text with unmarked unwanted words</returns>
        public static string Unmark(string text, string prefix = "<b><color=red>", string postfix = "</color></b>")
        {
            string result = text ?? string.Empty;

            //The different mangers all do the same.
            result = BadWordManager.Unmark(result, prefix, postfix);

            return result;
        }
        #endregion
    }
}
// Copyright 2015-2016 www.crosstales.com